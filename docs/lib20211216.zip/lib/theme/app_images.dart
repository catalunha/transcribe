class AppImages {
  static const login = "assets/images/login.png";
  static const google = "assets/images/google.png";
}
